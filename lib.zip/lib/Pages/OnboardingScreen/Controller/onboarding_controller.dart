import 'package:get/get.dart';

class OnboardingController extends GetxController{

  bool isSubmitting = false;



}
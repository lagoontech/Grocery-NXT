import 'package:flutter/foundation.dart';
import 'package:get/get.dart';
import '../../../Constants/api_constants.dart';
import '../../../Services/http_services.dart';
import '../../AllProductsView/Model/products_list_model.dart';
import '../Models/home_categories_model.dart';
import 'package:http/http.dart' as http;

class HomeProductsController extends GetxController{


}
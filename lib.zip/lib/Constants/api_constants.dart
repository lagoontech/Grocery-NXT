class ApiConstants {

  String baseUrl      = "http://grocerynxt.ltcloud247.com/api/v1/";
  String imageUrl     = "http://grocerynxt.ltcloud247.com/";
  //String baseUrl     = "http://grocerynxt.lagoontechcloud.com/api/v1/";
  //String baseUrl     = "http://ayushohealth.com/api/v1/";

  String categories  = "category";

  String allProducts = "product";

  String paymentStatusUpdateKey = "fdg86dghs54gh6gf5j7hdfg4hbf32gh1dfgh3d13";

}
import 'dart:ui';

class AppColors {

  static Color primaryColor = const Color(0xff42a73d);

  static Color secondaryColor = const Color(0xffe04373);

}